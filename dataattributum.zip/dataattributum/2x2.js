document.addEventListener("DOMContentLoaded", function () {
    let cellColors = ["", "", "", ""];
  
    let currentColor = "red";
  
    function changeColor(element) {
      let index = Array.from(element.parentNode.children).indexOf(element);
      if (cellColors[index] === "") {
        element.style.backgroundColor = currentColor;
        cellColors[index] = currentColor;
        currentColor = currentColor === "red" ? "blue" : "red";
      }
    }
  
    function renderContent() {
      let items = document.querySelectorAll(".item");
      items.forEach((item, index) => {
        item.addEventListener("click", function () {
          changeColor(this);
        });
      });
    }
  
    renderContent();
  });
  